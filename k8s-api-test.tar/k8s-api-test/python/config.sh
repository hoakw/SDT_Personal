#/bin/bash


CLUSTER_NAME=Server

